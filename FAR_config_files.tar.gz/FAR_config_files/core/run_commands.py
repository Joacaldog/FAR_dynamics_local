import os
import sys
file = sys.argv[1]
with open(file) as f:
	for line in f.readlines():
		command = line.strip()
		print(command)
		os.system(command)
